package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.vo.Person;

@Controller
public class DemoController {
	
	private static Map<String,Person> personPool = new HashMap<>();
	
	@PostConstruct
	public void init() {
		for(int i=0;i<10;i++) {
			personPool.put(("P000"+i), new Person(("P000"+i),("Tom-"+i),("P000"+i),(22+i)));
		}
	}

	@GetMapping("/login")
	public String login(ModelMap map) {
		map.put("msg", "");
		return "login";
	}
	@GetMapping("/logout")
	public String logout(HttpServletRequest request,ModelMap map) {
		request.getSession().removeAttribute("currentUser");
		map.put("msg", "Logout successfully.");
		return "login";
	}
	
	@GetMapping("/create")
	public String create(HttpServletRequest request,ModelMap map) {
		if(request.getSession().getAttribute("currentUser")==null) {
			map.put("msg", "");
			return "login";
		}
		map.put("selectedPerson", new Person());
		map.put("action", "Create User");
		return "user";
	}
	
	@GetMapping("/edit")
	public String edit(HttpServletRequest request,@RequestParam String id, ModelMap map) {
		if(request.getSession().getAttribute("currentUser")==null) {
			map.put("msg", "");
			return "login";
		}
		map.put("selectedPerson", DemoController.personPool.get(id));
		map.put("action", "Edit User");
		return "user";
	}
	
	@GetMapping("/delete")
	public String delete(HttpServletRequest request,@RequestParam String id, ModelMap map) {
		if(request.getSession().getAttribute("currentUser")==null) {
			map.put("msg", "");
			return "login";
		}
		DemoController.personPool.remove(id);
		map.put("allUsers", DemoController.personPool.values().toArray());
		return "demo";
	}
	
	@PostMapping("/save")
	public String save(HttpServletRequest request,@RequestParam String userId,@RequestParam String name,@RequestParam int age, ModelMap map) {
		if(request.getSession().getAttribute("currentUser")==null) {
			map.put("msg", "");
			return "login";
		}
		Person p = DemoController.personPool.get(userId);
		if(p==null) {
			DemoController.personPool.put(userId, new Person(userId,name,userId,age));
		}else {
			p.setName(name);
			p.setAge(age);
			DemoController.personPool.put(userId, p);
		}
		map.put("allUsers", DemoController.personPool.values().toArray());
		return "demo";
	}
	
	@PostMapping("/dologin")
	public String doLogin(HttpServletRequest request, @RequestParam("userId") String userId,@RequestParam("userPassword") String userPassword,ModelMap map) {
		Person p = DemoController.personPool.get(userId);
		if(p==null) {
			map.put("msg", "There is no such person.");
			return "login";
		}
		if(!p.getPassword().equals(userPassword)){
			map.put("msg", "Wrong password, please try again.");
			return "login";
		}
		request.getSession().setAttribute("currentUser", p);
		map.put("allUsers", DemoController.personPool.values().toArray());
		return "demo";
	}
}
