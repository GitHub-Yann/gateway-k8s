package com.yann.springboot.war.test.controller;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.refresh.ContextRefresher;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.druid.pool.DruidDataSource;
import com.yann.springboot.war.test.entity.CrudEntity;
import com.yann.springboot.war.test.mapper.CrudMapper;
import com.yann.springboot.war.test.vo.RespVO;
import com.yann.springboot.war.test.vo.SampleVO;

@RestController
public class TestController {
	private static final Logger LOGGER = LoggerFactory.getLogger(TestController.class);
	
	@Autowired
	private ContextRefresher contextRefresher;
	
	@Autowired
	private ApplicationContext applicationContext;
	
	@Resource
	private CrudMapper crudMapper;
	
	@Value("${abc.xxx}")
	private String name;

	@GetMapping("/api/sayhello")
    public String hello() {
		
		int cnt = Runtime.getRuntime().availableProcessors();
        return "hello "+name +", availableProcessors="+cnt;
    }
	
	@PostMapping("api/secret/change")
	public RespVO changePassword(@RequestBody SampleVO sampleVO){
		RespVO respVO = new RespVO();
		respVO.setResult(true);
		respVO.setErrorMsg("OK");
		
		
		DataSource ds = applicationContext.getBean(DataSource.class);
		if(ds instanceof DruidDataSource) {
			try {
				DruidDataSource dds = (DruidDataSource)ds;
				LOGGER.info("--------current hds: "+dds.toString());
				LOGGER.info("--------current url: "+dds.getUrl());
				LOGGER.info("--------current username: "+dds.getUsername());
				LOGGER.info("--------current password: "+dds.getPassword());
				if(sampleVO!=null && sampleVO.getSecretList()!=null && !sampleVO.getSecretList().isEmpty()) {
					LOGGER.info("--------new password: "+sampleVO.getSecretList().get(0).getValue());
					dds.setPassword(sampleVO.getSecretList().get(0).getValue());
					dds.restart();
				}
			} catch (Exception e) {
				LOGGER.error("=====EXP:",e);
			}
		}
		
		
		
		return respVO;
	}
	
	
	@GetMapping("api/do/query")  // id : 00923e0e-ceec-467d-bf0b-95847eaaa5ca
	public RespVO retrieveEntityById(@RequestParam(defaultValue = "") String id){
		RespVO respVO = new RespVO();
		respVO.setResult(true);
		respVO.setErrorMsg("OK");
		LOGGER.info("---------------------------query id = "+id);
		CrudEntity data = crudMapper.retrieveEntityById(id);
		respVO.setData(data);
		return respVO;
	}
	
	public static void main(String[] args) {
		System.out.println("/hr/api/v1/user/list".replaceAll("/(?<segment>/?.*)", "/cross/${segment}"));
		
	}
	
}
