package com.yann.springboot.war.test.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.yann.springboot.war.test.entity.CrudEntity;

@Mapper
public interface CrudMapper {

	CrudEntity retrieveEntityById(String id);
	
	int saveEntity(CrudEntity entity);
}
