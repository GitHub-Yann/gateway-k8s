package com.yann.springboot.war.test.entity;

public class CrudEntity {
	private String id;
	private String email;
	private String emailConstraint;
	private Boolean emailVerified;
	private Boolean enabled;
	private String federationLink;
	private String firstName;
	private String lastName;
	private String realmId;
	private String username;
	private Long createdTimestamp;
	private String serviceAccountClientLink;
	private Integer notBefore;
	private String mobile;
	private Integer loginPeriod;
	private Boolean mobileVerified;
	private String personalCode;


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getEmailConstraint() {
		return emailConstraint;
	}


	public void setEmailConstraint(String emailConstraint) {
		this.emailConstraint = emailConstraint;
	}


	public Boolean getEmailVerified() {
		return emailVerified;
	}


	public void setEmailVerified(Boolean emailVerified) {
		this.emailVerified = emailVerified;
	}


	public Boolean getEnabled() {
		return enabled;
	}


	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}


	public String getFederationLink() {
		return federationLink;
	}


	public void setFederationLink(String federationLink) {
		this.federationLink = federationLink;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getRealmId() {
		return realmId;
	}


	public void setRealmId(String realmId) {
		this.realmId = realmId;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public Long getCreatedTimestamp() {
		return createdTimestamp;
	}


	public void setCreatedTimestamp(Long createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}


	public String getServiceAccountClientLink() {
		return serviceAccountClientLink;
	}


	public void setServiceAccountClientLink(String serviceAccountClientLink) {
		this.serviceAccountClientLink = serviceAccountClientLink;
	}


	public Integer getNotBefore() {
		return notBefore;
	}


	public void setNotBefore(Integer notBefore) {
		this.notBefore = notBefore;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public Integer getLoginPeriod() {
		return loginPeriod;
	}


	public void setLoginPeriod(Integer loginPeriod) {
		this.loginPeriod = loginPeriod;
	}


	public Boolean getMobileVerified() {
		return mobileVerified;
	}


	public void setMobileVerified(Boolean mobileVerified) {
		this.mobileVerified = mobileVerified;
	}


	public String getPersonalCode() {
		return personalCode;
	}


	public void setPersonalCode(String personalCode) {
		this.personalCode = personalCode;
	}


	@Override
	public String toString() {
		return "CrudEntity [id=" + id + ", email=" + email + ", emailConstraint=" + emailConstraint + ", emailVerified="
				+ emailVerified + ", enabled=" + enabled + ", federationLink=" + federationLink + ", firstName="
				+ firstName + ", lastName=" + lastName + ", realmId=" + realmId + ", username=" + username
				+ ", createdTimestamp=" + createdTimestamp + ", serviceAccountClientLink=" + serviceAccountClientLink
				+ ", notBefore=" + notBefore + ", mobile=" + mobile + ", loginPeriod=" + loginPeriod
				+ ", mobileVerified=" + mobileVerified + ", personalCode=" + personalCode + "]";
	}
}