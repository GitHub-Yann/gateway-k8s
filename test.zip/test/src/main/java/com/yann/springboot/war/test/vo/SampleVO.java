package com.yann.springboot.war.test.vo;

import java.util.List;

public class SampleVO {
	private List<KeyValueVO> secretList;

	public List<KeyValueVO> getSecretList() {
		return secretList;
	}

	public void setSecretList(List<KeyValueVO> secretList) {
		this.secretList = secretList;
	}
}
