package org.yann.eureka.client.demo.vo;

public class ContextUserVO {
	private String tenant;
    private String userName;
    private String personId;
    public ContextUserVO() {
        super();
    }
    public ContextUserVO(String tenant, String userName, String personId) {
        super();
        this.tenant = tenant;
        this.userName = userName;
        this.personId = personId;
    }
    
    public String getTenant() {
		return tenant;
	}
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPersonId() {
		return personId;
	}
	public void setPersonId(String personId) {
		this.personId = personId;
	}
	@Override
    public String toString() {
        return this.tenant+"|"+this.userName;
    }
}
