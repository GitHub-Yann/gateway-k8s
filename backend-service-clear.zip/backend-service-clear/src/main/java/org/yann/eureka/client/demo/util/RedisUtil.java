package org.yann.eureka.client.demo.util;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@Component
public class RedisUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RedisUtil.class);
	
	private static RedisUtil redisUtil;

	@Autowired
	private JedisPool jedisPool;
	
	@Value("${prefix.name.for.redis}")
	private String cacheKeyPrefixProd;
	
	@PostConstruct
    public void init() {
		redisUtil = this;
    }
	
	private String getValueFromRedisByKey(String key) {
		Jedis jedis = null;
		try {
			jedis = jedisPool.getResource();
			return jedis.get(key);
		} catch (Exception ex) {
			LOGGER.error("getValueFromRedisByKey......>get [{}] exception:{}",key,ExceptionUtil.getStackTraceString(ex));
			return null;
		} finally {
			if(jedis!=null) {
				jedis.close();
			}
		}
	}
	
	private String setValueIntoRedisByKey(String key, String value,long expireSecond) {
		Jedis jedis = null;
		try {
			jedis = jedisPool.getResource();
			jedis.set(key, value);
			return String.valueOf(jedis.expire(key,(int)expireSecond));
		} catch (Exception ex) {
			LOGGER.error("setValueIntoRedisByKey......>set [{},{},{}]exception:{}"
					,key,value,expireSecond,ExceptionUtil.getStackTraceString(ex));
			return "0";
		} finally {
			if(jedis!=null) {
				jedis.close();
			}
		}
	}
	
	private String setValueIntoRedisByKey(String key, String value) {
		Jedis jedis = null;
		try {
			jedis = jedisPool.getResource();
			return jedis.set(key, value);
		} catch (Exception ex) {
			LOGGER.error("setValueIntoRedisByKey......>set[{},{}] exception:{}",key,value,ExceptionUtil.getStackTraceString(ex));
			return "0";
		} finally {
			if(jedis!=null) {
				jedis.close();
			}
		}
	}
	
	private Long delFromRedisByKey(String... keys) {
		Jedis jedis = null;
		try {
			jedis = jedisPool.getResource();
			return jedis.del(keys);
		} catch (Exception ex) {
			LOGGER.error("delFromRedisByKey......>del [{}]exception:{}",keys,ExceptionUtil.getStackTraceString(ex));
			return 0L;
		} finally {
			if(jedis!=null) {
				jedis.close();
			}
		}
	}
	
	
	/*********************************************************static method*************************************/
	
	/**
	 * 
	 * @param prefixContainer    e.g. token/nonce/iphash/unreachable
	 * @param realKey            e.g. xyz
	 * @return    gatewayL:unreachable:xyz
	 */
	public static String generateKey(String prefixContainer,String realKey) {
		return redisUtil.cacheKeyPrefixProd.concat(":")
				.concat(prefixContainer).concat(":").concat(realKey);
	}
	
	public static void removeTokenKeyFromCache(String key) {
		try {
			redisUtil.delFromRedisByKey(key);
		}catch(Exception e) {
			LOGGER.error("removeKeyFromCache......>key[{}] exception:{}",key,ExceptionUtil.getStackTraceString(e));
		}
	}
	
	public static void storeKeyIntoCache(String key,Object value,long expireSecond) {
		LOGGER.info("storeKeyIntoCache......>key={}, expireSecond={}",key,expireSecond);
		try {
			String jsonStr =  JSONObject.toJSONString(value);
			if(expireSecond==0L) {//infinite
				redisUtil.setValueIntoRedisByKey(key, jsonStr);
			}else {
				redisUtil.setValueIntoRedisByKey(key, jsonStr,expireSecond);
			}
		}catch(Exception e) {
			LOGGER.error("storeKeyIntoCache......>key[{}] exception:{}",key,ExceptionUtil.getStackTraceString(e));
		}
	}
	
	
	public static String extractCommonFromCache(String key) {
		try {
			String result = redisUtil.getValueFromRedisByKey(key);
			return result!=null?result:"";
		}catch(Exception e) {
			LOGGER.error("extractCommonFromCache......>key[{}] exception:{}",key,ExceptionUtil.getStackTraceString(e));
			return "";
		}
	}
}
