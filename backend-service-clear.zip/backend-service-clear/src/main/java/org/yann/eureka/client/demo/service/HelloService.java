package org.yann.eureka.client.demo.service;

public interface HelloService {

	String hello(String s);
	
}
