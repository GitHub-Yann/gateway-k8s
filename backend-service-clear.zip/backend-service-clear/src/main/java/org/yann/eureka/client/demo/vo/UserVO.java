package org.yann.eureka.client.demo.vo;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

public class UserVO {
	private String userName;
	private Integer age;
	private String mobile;
	private String realmName;
	private String address;
	private String companyCode;
	List<PropertyVO> hobbies;
	List<PropertyVO> properties;
	Map<String,String> attrMap;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	public String getRealmName() {
		return realmName;
	}
	public void setRealmName(String realmName) {
		this.realmName = realmName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public List<PropertyVO> getHobbies() {
		return hobbies;
	}
	public void setHobbies(List<PropertyVO> hobbies) {
		this.hobbies = hobbies;
	}
	public List<PropertyVO> getProperties() {
		return properties;
	}
	public void setProperties(List<PropertyVO> properties) {
		this.properties = properties;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	
	
	public Map<String, String> getAttrMap() {
		return attrMap;
	}
	public void setAttrMap(Map<String, String> attrMap) {
		this.attrMap = attrMap;
	}
	
	@Override
	public String toString() {
		return "UserVO [userName=" + userName + ", age=" + age + ", mobile=" + mobile + ", realmName=" + realmName
				+ ", address=" + address + ", companyCode=" + companyCode + ", hobbies=" + hobbies + ", properties="
				+ properties + ", attrMap=" + attrMap + "]";
	}
	public static void main(String[] args) {
		UserVO u = new UserVO();
		u.setAddress("Suzhou");
		u.setAge(11);
		u.setMobile("11111111111");
		u.setRealmName("Yann");
		u.setUserName("Yann");
		List<PropertyVO> plist = new ArrayList<PropertyVO>();
		List<PropertyVO> hlist = new ArrayList<PropertyVO>();
		PropertyVO p = null;
		for(int i=0;i<15000;i++) {
			p = new PropertyVO();
			p.setKey("property-"+i);
			p.setValue("p-value-"+i);
			plist.add(p);
		}
		for(int i=0;i<15000;i++) {
			p = new PropertyVO();
			p.setKey("hobby-"+i);
			p.setValue("h-value-"+i);
			hlist.add(p);
		}
//		u.setProperties(plist);
//		u.setHobbies(hlist);
		System.out.println(u.toString());
		long l = Calendar.getInstance().getTimeInMillis();
		
		TreeMap m = JSONObject.parseObject(JSON.toJSONString(u),TreeMap.class);
		
//		System.out.println(JSONObject.toJSONString(m,SerializerFeature.MapSortField));
		String str="hello world!";
        FileWriter writer;
        try {
            writer = new FileWriter("C:\\Users\\yann.chen\\Desktop\\new 1.txt");
            writer.write(JSONObject.toJSONString(m,SerializerFeature.MapSortField));
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		System.out.println( Calendar.getInstance().getTimeInMillis()-l);
	}
}
