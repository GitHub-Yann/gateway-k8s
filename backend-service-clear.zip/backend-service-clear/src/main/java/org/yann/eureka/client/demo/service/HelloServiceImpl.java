package org.yann.eureka.client.demo.service;

import org.springframework.stereotype.Service;

@Service
public class HelloServiceImpl implements HelloService {
	
//	@Autowired
//	private ServiceEntityMapper serviceEntityMapper;

	@Override
	public String hello(String s) {
		StringBuilder builder = new StringBuilder("Hello ");
		return builder.append(s).toString();
	}


}
