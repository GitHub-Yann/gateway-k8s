package org.yann.eureka.client.demo.util;

import java.net.URL;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.yann.eureka.client.demo.vo.ContextUserVO;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.UrlJwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.DecodedJWT;
 
public class TokenVerification {
	
	private static Map<String, PublicKey> publicKeyMap = new HashMap<String, PublicKey>();
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TokenVerification.class);
	
	public static String verifyToken(String realm, String token,String whichSso) {
		try {
			String authUrl = "";
			if("D1".equals(whichSso)) {
				authUrl = "https://ssoplus-d.gaiaworkforce.com/auth;https://ssoplus-d.gaiaworkforce.com/auth";
			}else if("D2".equals(whichSso)) {
				authUrl = "https://ssoplus-dev.gaiaworkforce.com/auth;https://ssoplus-dev.gaiaworkforce.com/auth";
			}else if("Q".equals(whichSso)) {
				authUrl = "https://ssoplus-d.gaiaworkforce.com/auth;https://ssoplus-d.gaiaworkforce.com/auth";
			}else if("S".equals(whichSso)) {
				authUrl = "https://ssoplus-s.gaiaworkforce.com/auth;https://ssoplus-s.gaiaworkforce.com/auth";
			}else if(whichSso.startsWith("XYZ")) {
				String newUrl = "https://"+whichSso.substring(3, whichSso.length())+"/auth";
				authUrl = newUrl+";"+newUrl;
			}
					
			DecodedJWT jwt = JWT.decode(token);
			String issuer = authUrl.split(";")[0] + "/realms/" + realm;
			if (!publicKeyMap.containsKey(realm)) {
				LOGGER.error("verifyToken......>set the key "+realm+" into map");
				jwt = JWT.decode(token);
				JwkProvider jwkProvider = new UrlJwkProvider(
						new URL(authUrl.split(";")[1] + "/realms/" + realm + "/protocol/openid-connect/certs"));
				Jwk jwk = jwkProvider.get(jwt.getKeyId());
				publicKeyMap.put(realm, jwk.getPublicKey());
			}
			Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) publicKeyMap.get(realm), null);
			JWTVerifier verifier = JWT.require(algorithm).withIssuer(issuer).build(); // Reusable verifier instance
			jwt = verifier.verify(token);
		} catch (Exception e) {
			
			if (e instanceof TokenExpiredException) {
				return "EXP";
			} else {
				return "INV";
			}
		}
		return "PASS";
	}

    public static ContextUserVO getContextUserFromToken(String token) {
        ContextUserVO user = new ContextUserVO();
        if(!StringUtils.isEmpty(token)) {
            try {
                DecodedJWT jwt = JWT.decode(token.substring(7));
                String tenant = jwt.getClaims().get("tenant")!=null?jwt.getClaims().get("tenant").asString():"";
                String userName = jwt.getClaims().get("preferred_username")!=null?jwt.getClaims().get("preferred_username").asString():"";
                String personId = jwt.getClaims().get("person_id")!=null?jwt.getClaims().get("person_id").asString():"";
                user = new ContextUserVO(tenant,userName,personId);
            }catch(Exception e) {
                 
            }
        }
        return user;
    }
}
