package org.yann.eureka.client.demo.vo;

import java.net.URI;

import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;

/**
 * HttpClient Delete工具类，可以传递body参数
 */
public class HttpDeleteWithBodyObj extends HttpEntityEnclosingRequestBase {

    public static final String METHOD_NAME = "DELETE";

    @Override
    public String getMethod() {
        return METHOD_NAME;
    }

    public  HttpDeleteWithBodyObj(final String uri){
        super();
        setURI(URI.create(uri));
    }

    public HttpDeleteWithBodyObj(final URI uri){
        super();
        setURI(uri);
    }

    public HttpDeleteWithBodyObj(){
        super();
    }
}
