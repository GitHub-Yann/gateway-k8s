package org.yann.eureka.client.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.yann.eureka.client.demo.service.HelloService;
import org.yann.eureka.client.demo.service.HelloServiceImpl;

@SpringBootTest
public class ServiceTests {

	@InjectMocks
	private HelloService helloService = new HelloServiceImpl();
	
	@Test
	public void contextLoads() {
		assertEquals("Hello yann",helloService.hello("yann"));
	}
}

