package org.yann.eureka.client.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ControllerTests {

	@LocalServerPort
    private int port;
	
	@Autowired
    private TestRestTemplate restTemplate;
	
	@Test
	public void contextLoads() throws RestClientException, MalformedURLException {
		ResponseEntity<String> response = restTemplate.getForEntity(new URL("http://localhost:" + port + "/testhealthcheck").toString(), String.class);
		System.out.println("============================================================="+response.getBody());
	    assertEquals("OK", response.getBody());
	}

}

