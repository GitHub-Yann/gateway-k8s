//package org.yann.eureka.client.demo.aspect;
//
//import java.time.Duration;
//import java.util.Enumeration;
//
//import javax.servlet.http.Cookie;
//import javax.servlet.http.HttpServletRequest;
//
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Pointcut;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import io.micrometer.core.instrument.MeterRegistry;
//import io.micrometer.core.instrument.Timer;
//import io.prometheus.client.Counter;
//
//@Aspect
//@Component
//public class PrometheusMetricsAspect {
//	
//	private static final Logger LOGGER = LoggerFactory.getLogger(PrometheusMetricsAspect.class);
//	
//	private static final Counter requestTotal = Counter.build("counter_all_yann123", "counter_all_yann_help123").labelNames("api_path_string").register();
//
//	@Pointcut("execution(public * org.yann.eureka.client.demo.controller.HelloServiceController.test*(..))")
//    public void pcMethod() {
//    }
//	
//	@Autowired
//	private MeterRegistry registry;
//	
//	@Around("pcMethod()")
//    public Object aroundAdvice(ProceedingJoinPoint pjp) throws Exception{
//		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
//        String name = request.getRequestURI();
//        LOGGER.info("aroundAdvice :{}",name);
//        this.printCookieHeader(request);
////        Timer t = Metrics.timer("api.path.call.counter","apiPath", name);
////        Timer.Sample t = Timer.start(registry);
//        Timer t = Timer.builder("yann.timer").tag("path.request.time", name).sla(Duration.ofMillis(50),Duration.ofMillis(100),Duration.ofMillis(200),Duration.ofMillis(500))
//        		.minimumExpectedValue(Duration.ofMillis(50))
//        		   .maximumExpectedValue(Duration.ofSeconds(2)).register(registry);
////        t.stop(registry.timer("my.timer", "response", "2222222222222222"));
//        return t.recordCallable(()->{
//        	try {
//    			return pjp.proceed();
//    		} catch (Throwable e) {
//    			LOGGER.error("Exception{}",e.getMessage());
//    			return null;
//    		}
//        });
//        
//	}
//	
//	private void printCookieHeader(HttpServletRequest request) {
//		Enumeration<String> headers = request.getHeaderNames();
//		String header;
//		String printCookieHeader = request.getHeader("printCookieHeader");
//		if("Y".equals(printCookieHeader)) {
//			LOGGER.info("----------------------------------------------------------------------------------------------------------------------1");
//			
//			while (headers.hasMoreElements()) {
//				header = headers.nextElement();
//				LOGGER.info("printCookieHeader......>Header name={}, value={}",header,request.getHeader(header));
//			}
//			Cookie[] cookieArr = request.getCookies() == null ? (new Cookie[] {}) : request.getCookies();
//			for (Cookie cookie : cookieArr) {
//				LOGGER.info("printCookieHeader......>Cookie name={}, value={}",cookie.getName(),cookie.getValue());
//			}
//			LOGGER.info("----------------------------------------------------------------------------------------------------------------------2");
//		}
//	}
//}
