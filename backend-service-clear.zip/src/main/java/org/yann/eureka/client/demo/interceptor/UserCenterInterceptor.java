package org.yann.eureka.client.demo.interceptor;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.yann.eureka.client.demo.util.TokenVerification;
import org.yann.eureka.client.demo.vo.ContextUserVO;

public class UserCenterInterceptor implements HandlerInterceptor{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserCenterInterceptor.class);
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)throws Exception {
        String authorization = request.getHeader("Authorization");
        ContextUserVO user = TokenVerification.getContextUserFromToken(authorization);
        request.setAttribute("contextUser", user);
        LOGGER.info("UserCenterInterceptor.......preHandle");
        Cookie c = new Cookie("xxxxxxxxxxx","yyyyyyyyyyyyy");
        c.setMaxAge(36000);
        c.setSecure(true);
        c.setHttpOnly(true);
        c.setPath("/");
        response.addCookie(c);
        return true;
    }
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}
	
	
    
    
}
