package org.yann.eureka.client.demo.util;

public class ExceptionUtil {
  public static final int LINE_NUMBER=5;
	
  public static String getStackTraceString(Throwable ex) {
    StackTraceElement[] traceElements = ex.getStackTrace();
		 
    StringBuilder traceBuilder = new StringBuilder();
    traceBuilder.append(ex.getMessage()).append(";");
    if (traceElements != null && traceElements.length > 0) {
    	int j = traceElements.length;
    	if(traceElements.length>=LINE_NUMBER) {
    		j=LINE_NUMBER;
    	}
      for (int i=0;i<j;i++) {
        traceBuilder.append(traceElements[i].toString());
        traceBuilder.append(";");
      }
    }
 
    return traceBuilder.toString();
	}
}
