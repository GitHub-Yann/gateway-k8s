package org.yann.eureka.client.demo.util;

import java.net.URI;
import java.net.URISyntaxException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SignUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(SignUtil.class);
	
	/**
	 * convert the byte array to string
     *
     * @param
     * @return
     */
    public static String byteArrayToHexString(byte[] b) {
        StringBuilder hs = new StringBuilder();
        String stmp;
        for (int n = 0; b!=null && n < b.length; n++) {
            stmp = Integer.toHexString(b[n] & 0XFF);
            if (stmp.length() == 1)
                hs.append('0');
            hs.append(stmp);
        }
        return hs.toString().toLowerCase();
    }
    /**
     * sha256_HMAC encrypt the message
     * @param message 
     * @param secret  
     * @return 
     */
    public static String sha256HMAC(String message, String secret) {
        String hash = "";
        try {
            Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
            SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
            sha256_HMAC.init(secret_key);
            byte[] bytes = sha256_HMAC.doFinal(message.getBytes());
            hash = byteArrayToHexString(bytes);
        } catch (Exception e) {
            LOGGER.error("sha256HMAC......>exception:",e);
        }
        return hash;
    }
    
    
    
    public static  String test() {
    	String s = "{\"address\":\"ssssssss\",\"age\":\"ssssssssasdfadsfsafdsafda\",\"ajytff\":\"ssssssss\",\"asdf\":\"ssssssss\",\"asdfcccc\":\"ssssssss\",\"fff\":\"ssssssss\",\"ggasdassg\":\"ssssseeeeeeeeeeeeeeeeeeeeeeeesss\",\"ggg\":\"sssssfffffffffffffffffsss\",\"gwEfagg\":\"11111111你\",\"gwefagg\":\"ssssssss\",\"iugggg\":\"ssssssswwwwwwwwwwwwwwwwwwwwwsb\",\"jsdgf\":\"ssssssss\",\"mobile\":\"ssssasdfasfasfasfssss\",\"oiugga\":\"ssssssss\",\"oklkj\":\"sssssdddddddddddddddsssb\",\"olkjh\":\"ssssssss\",\"properties\":[{\"age\":\"a00000\",\"key\":\"key002\",\"name\":\"n00000\",\"value\":\"value0002\"},{\"age\":\"a1111\",\"key\":\"key001\",\"name\":\"n01111\",\"value\":\"value0001\"}],\"realmName\":\"ssasdfassssssssssssssssssss\",\"userName\":\"ssssssssasdfasdfasdfasfsafsaf\",\"wefasdf\":\"ssssssss\",\"wflkjhhh\":\"ssssssss\",\"xxx\":\"ssssssss\"}tenantHRONEHRCOREtimestamp1561533729nonce156153372911";
    	String newSign = SignUtil.sha256HMAC(s, "gaiaworks");
    	return newSign;
    }
    
    public static void main(String[] args) {
    	String value = "asdfdas.ssadsfa.com/asda.html";
    	try {
			URI u = new URI(value).parseServerAuthority();
			System.out.println(u.getHost());
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    
}
