package org.yann.eureka.client.demo.util;

import java.util.HashSet;
import java.util.Set;

public class Test {
	public static void main(String[] args) {
		String str = "abcdbcd";
		if(str==null || "".equals(str)) {
			System.out.println("max sub lenth: 0");
		}
		int len = str.length();
		int result=0;
		int left=0;
		int right=0;
		Set<Character> set = new HashSet<>();
		while(left<len && right<len) {
			if(set.contains(str.charAt(right))) {
				//如果包含说明当前 result已经是目前 最大的长度了，移动左侧游标，
				//直到移动到 左侧游标指向的元素 和 当前右侧元素相同的地方 的下一个位置
				set.remove(str.charAt(left));
				left++;
			}else {
				set.add(str.charAt(right));
				right++;
				result = Math.max(result, right-left);
			}
		}
		System.out.println(result);
	}
}