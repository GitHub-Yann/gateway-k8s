package org.yann.eureka.client.demo.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yann.eureka.client.demo.vo.HttpDeleteWithBodyObj;

public class HttpUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtil.class);
	
	private static final String CONTENT_TYPE="Content-Type";
	private static final String UTF_8="UTF-8";
	private static final String CONTENT_TYPE_JSON="application/json;charset=UTF-8";

    public static byte[] readInputStream(InputStream inStream) throws Exception {
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len = 0;
        while ((len = inStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, len);
        }
        byte[] data = outStream.toByteArray();
        outStream.close();
        inStream.close();
        return data;
    }
    
    public static String sendDeleteWithBodyEntityOrNot(String requestUrl,Map<String,String> headerMap,String bodyJson){
    	HttpDeleteWithBodyObj httpDelete = new HttpDeleteWithBodyObj(requestUrl);
    	if(headerMap!=null && !headerMap.isEmpty()) {
    		for(Map.Entry<String, String> entry: headerMap.entrySet()) {
    			httpDelete.setHeader(entry.getKey(), entry.getValue());
			}
		}
    	CloseableHttpResponse response = null;
    	try(CloseableHttpClient httpClient = HttpClients.createDefault()) {
            httpDelete.setHeader(CONTENT_TYPE, CONTENT_TYPE_JSON);
            if(bodyJson!=null) {
            	httpDelete.setEntity(new StringEntity(bodyJson, UTF_8));
            }
            response = httpClient.execute(httpDelete);
            int status = response.getStatusLine().getStatusCode();
            LOGGER.info("DELETE URL {}, status {}", requestUrl, status);
            return EntityUtils.toString(response.getEntity(), UTF_8);
        } catch (Exception e) {
        	LOGGER.error("DELETE exception, URL {}, status {}",requestUrl,e);
        	return "EXCEPTION";
        } finally {
			try {
				if (response != null) {
					response.close();
				}
			} catch (IOException e) {
				LOGGER.error("DELETE exception {}", e.getMessage(), e);
			}
		}
    }
    
    public static String sendGet(String urlParam,Map<String,String> headerMap) {
		HttpGet httpGet = new HttpGet(urlParam);
		if(headerMap!=null && !headerMap.isEmpty()) {
			for(Map.Entry<String, String> entry: headerMap.entrySet()) {
				httpGet.setHeader(entry.getKey(), entry.getValue());
			}
		}
		CloseableHttpResponse response = null;
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			response = httpClient.execute(httpGet);
			int status = response.getStatusLine().getStatusCode();
			LOGGER.info("GET URL {}, status {}", urlParam, status);
			return EntityUtils.toString(response.getEntity(), UTF_8);
		} catch (IOException e) {
			LOGGER.error("GET exception, URL {}, status {}", urlParam, e.getMessage(), e);
			return "EXCEPTION";
		} finally {
			try {
				if (response != null) {
					response.close();
				}
			} catch (IOException e) {
				LOGGER.error("GET exception {}", e.getMessage(), e);
			}
		}
	}
    
    public static String sendPut(String urlParam,Map<String,String> headerMap,String bodyJson) {
		HttpPut httpPut = new HttpPut(urlParam);
		if(headerMap!=null && !headerMap.isEmpty()) {
			for(Map.Entry<String, String> entry: headerMap.entrySet()) {
				httpPut.setHeader(entry.getKey(), entry.getValue());
			}
		}
		CloseableHttpResponse response = null;
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			httpPut.setEntity(new StringEntity(bodyJson, UTF_8));
			httpPut.setHeader(CONTENT_TYPE, CONTENT_TYPE_JSON);
			response = httpClient.execute(httpPut);
			int status = response.getStatusLine().getStatusCode();
			LOGGER.info("PUT URL {}, status {}", urlParam, status);
			return EntityUtils.toString(response.getEntity(), UTF_8);
		} catch (IOException e) {
			LOGGER.error("PUT exception, URL {}, status {}", urlParam, e.getMessage(), e);
			return "EXCEPTION";
		} finally {
			try {
				if (response != null) {
					response.close();
				}
			} catch (IOException e) {
				LOGGER.error("PUT exception {}", e.getMessage(), e);
			}
		}
	}
    
    public static String sendPost(String urlParam,Map<String,String> headerMap,String bodyJson) {
		HttpPost httpPost = new HttpPost(urlParam);
		if(headerMap!=null && !headerMap.isEmpty()) {
			for(Map.Entry<String, String> entry: headerMap.entrySet()) {
				httpPost.setHeader(entry.getKey(), entry.getValue());
			}
		}
		CloseableHttpResponse response = null;
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			httpPost.setHeader(CONTENT_TYPE, CONTENT_TYPE_JSON);
			httpPost.setEntity(new StringEntity(bodyJson, UTF_8));
			response = httpClient.execute(httpPost);
			int status = response.getStatusLine().getStatusCode();
			LOGGER.info("POST URL {}, status {}", urlParam, status);
			return EntityUtils.toString(response.getEntity(), UTF_8);
		} catch (IOException e) {
			LOGGER.error("POST exception, URL {}, status {}", urlParam, e.getMessage(), e);
			return "EXCEPTION";
		} finally {
			try {
				if (response != null) {
					response.close();
				}
			} catch (IOException e) {
				LOGGER.error("POST exception {}", e.getMessage(), e);
			}
		}
	}
    
    public static void main(String[] args) throws IOException {
    	String requestUrl="http://localhost:9911/api/demo/testdelete?name=xxxxxxxxxxxxxxxxxxxxxx";
    	System.out.println(HttpUtil.sendDeleteWithBodyEntityOrNot(requestUrl,null,null));
	}
}

