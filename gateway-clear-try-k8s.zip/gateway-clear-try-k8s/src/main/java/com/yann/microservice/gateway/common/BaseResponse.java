package com.yann.microservice.gateway.common;

public class BaseResponse {
  public static final int RETURN_CODE_200 = 200;
  private int code = RETURN_CODE_200;
  private String message;
  private Object data;

  public BaseResponse(int code, String message,Object obj) {
    this.code = code;
    this.message = message;
    this.data = obj;
  }

  public BaseResponse() {
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}


}

