package com.yann.microservice.gateway.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.kubernetes.discovery.KubernetesServiceInstance;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yann.microservice.gateway.common.BaseResponse;
import com.yann.microservice.gateway.common.GatewayConstant;

@RestController
public class GatewayRestController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GatewayRestController.class);

	@Value("${project.version}")
	private String projectVersion;

	@Autowired
	private DiscoveryClient discoveryClient;

	@GetMapping("gateway/healthcheck")
	public BaseResponse healthCheck() {
		BaseResponse response = new BaseResponse();
		response.setMessage("Gateway[" + projectVersion + "] is alive.");
		return response;
	}

	@GetMapping("gateway/timeout")
	public BaseResponse timeout() {
		BaseResponse response = new BaseResponse();
		response.setCode(GatewayConstant.NUMBER_503);
		response.setMessage("Sorry, the downstream system is unavailable.");
		return response;
	}
	
	@GetMapping("gateway/services")
	public List<String> services() {

		List<String> serviceIds = this.discoveryClient.getServices();
		for (String id : serviceIds) {
			List<ServiceInstance> ins = this.discoveryClient.getInstances(id);
			if (ins != null && ins.size() > 0) {
				for (ServiceInstance in : ins) {
					if (in instanceof KubernetesServiceInstance) {
						KubernetesServiceInstance targetIns = (KubernetesServiceInstance) in;
						LOGGER.info("====================================================");
						LOGGER.info("---{}---{}---{}---{}---{}", targetIns.getNamespace(), targetIns.getServiceId(),
								targetIns.getInstanceId(), targetIns.getHost(),targetIns.getUri());
						if (targetIns.getMetadata() != null && targetIns.getMetadata().size() > 0) {
							for (Map.Entry<String, String> entry : targetIns.getMetadata().entrySet()) {
								LOGGER.info("key={},value={}", entry.getKey(), entry.getValue());
							}
						}
					}
				}
			}
		}
		return serviceIds;
	}

}
